﻿//@author: Chang Liu & Yi-Hsin (Emily) Hsu

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using readAPI0305_1.Models;


using System.Net;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;

namespace readAPI0305_1.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            ViewData["Message"] = "Your home page.";
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        public IActionResult Patient()
        {
            Console.WriteLine("----------------------------Patient----------------------------");
            //Hosted web API REST Service base url  
            string uri = "http://smarthomemedicaladhearanceapi.azurewebsites.net/api/Patients/1";
            Patient patients = new Patient();
            // call the openweathermap API
            using (var client = new HttpClient())
            {
                HttpResponseMessage Res = client.GetAsync(new Uri(uri)).Result;

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    var patientResponse = Res.Content.ReadAsStringAsync().Result;

                    patients = JsonConvert.DeserializeObject<Patient>(patientResponse);

                    /*
                    Console.WriteLine("----------------------------result----------------------------");
                    Console.WriteLine("Patient First Name: " + patients.name);
                    Console.WriteLine();

                    Console.WriteLine("Patient Last Name: " + patients.sys.country);
                    Console.WriteLine();

                    Console.WriteLine("Patient Age: " + patients.main.temp + "°C");
                    Console.WriteLine();

                    Console.WriteLine("Drug Instruction: " + patients.weather[0].main +
                        " - " + patients.weather[0].description);
                    Console.WriteLine();*/
                }
            }

            return View("Patient", patients);
        }


        public IActionResult Schedule()
        {
            Console.WriteLine("----------------------------Schedule----------------------------");
            //Hosted web API REST Service base url  
            string uri = "http://smarthomemedicaladhearanceapi.azurewebsites.net/api/PSchedules/1";
            List<Schedule> schedule = new List<Schedule>();
            // call the openweathermap API
            using (var client = new HttpClient())
            {
                HttpResponseMessage Res = client.GetAsync(new Uri(uri)).Result;

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    var scheduleResponse = Res.Content.ReadAsStringAsync().Result;

                    schedule = JsonConvert.DeserializeObject<List<Schedule>>(scheduleResponse);

                    /*
                    Console.WriteLine("----------------------------result----------------------------");
                    Console.WriteLine("Patient First Name: " + patients.name);
                    Console.WriteLine();

                    Console.WriteLine("Patient Last Name: " + patients.sys.country);
                    Console.WriteLine();

                    Console.WriteLine("Patient Age: " + patients.main.temp + "°C");
                    Console.WriteLine();

                    Console.WriteLine("Drug Instruction: " + patients.weather[0].main +
                        " - " + patients.weather[0].description);
                    Console.WriteLine();*/
                }
            }

            return View("Schedule", schedule);
        }

        public IActionResult Compliance()
        {
            
            Console.WriteLine("----------------------------Comliance----------------------------");
            //Hosted web API REST Service base url  
            string uri = "http://smarthomemedicaladhearanceapi.azurewebsites.net/api/MediactionDetails/1";
            Compliance compliance = new Compliance();
            // call the openweathermap API
            using (var client = new HttpClient())
            {
                HttpResponseMessage Res = client.GetAsync(new Uri(uri)).Result;

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    var complianceResponse = Res.Content.ReadAsStringAsync().Result;
                    compliance = JsonConvert.DeserializeObject<Compliance>(complianceResponse);
                }
            }
            return View("Compliance", compliance);

        }
    }
}
