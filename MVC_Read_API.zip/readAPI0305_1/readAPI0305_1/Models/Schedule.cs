﻿//@author: Chang Liu & Yi-Hsin (Emily) Hsu
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace readAPI0305_1.Models
{
    public class Schedule
    {
        [JsonProperty("drugId")]//serilize 
        public string DrugId { get; set; }

        [JsonProperty("drugDose")]//serilize 
        public string DrugDose { get; set; }

        [JsonProperty("scheduleTime")]//serilize 
        public IList<string> ScheduleTime { get; set; }
    }
}