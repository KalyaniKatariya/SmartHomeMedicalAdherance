﻿//@author: Chang Liu & Yi-Hsin (Emily) Hsu

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace readAPI0305_1.Models
{
    public class Compliance
    {
        [JsonProperty("status")]//serilize 
        public bool Status { get; set; }

        [JsonProperty("details")]//serilize 
        public string Details { get; set; }
    }
}