//@author: Chang Liu & Yi-Hsin (Emily) Hsu
using System;

namespace readAPI0305_1.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}