﻿//@author: Chang Liu & Yi-Hsin (Emily) Hsu

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace readAPI0305_1.Models
{
    public class Patient
    {
        [JsonProperty("firstName")]//serilize 
        public string FirstName { get; set; }

        [JsonProperty("lastName")]//serilize 
        public string LastName { get; set; }

        [JsonProperty("age")]//serilize 
        public string Age { get; set; }

        [JsonProperty("email")]//serilize 
        public string Email { get; set; }

        [JsonProperty("address")]//serilize 
        public string Address { get; set; }

        [JsonProperty("medicinName")]//serilize 
        public string MedicinName { get; set; }

        [JsonProperty("drugDose")]//serilize 
        public string DrugDose { get; set; }

        [JsonProperty("drugInstruction")]//serilize 
        public string DrugInstruction { get; set; }

        [JsonProperty("caregiverName")]//serilize 
        public string CaregiverName { get; set; }

        [JsonProperty("doctorName")]//serilize 
        public string DoctorName { get; set; }
    }
}
