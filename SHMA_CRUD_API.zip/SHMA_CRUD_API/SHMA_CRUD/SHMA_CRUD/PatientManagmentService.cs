﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMA_CRUD
{
      
    public class PatientManagmentService
    {
        [JsonProperty("id")]//serilize 
        public string Id { get; set; }

        [JsonProperty("name")]//serilize 
        public string Name { get; set;}

        [JsonProperty("drug_name")]//serilize (used camel case style as it is Json based)
        public string Drug_name { get; set; }





    }
}
