﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/*Repo model reads all the records from the database and then they are
filtred again at APP model and only information that is related to user is displayed*/
namespace SHMA_CRUD.RepoModel
{
    public class PatientComplienceDoc
    {
        [JsonProperty("patientId")]//serilize 
        public string PatientId { get; set; }

        [JsonProperty("medicationId")]//serilize 
        public string MedicationId { get; set; }

        [JsonProperty("scheduleTime")]//serilize 
        public DateTime ScheduleTime { get; set; }

        [JsonProperty("drugtaken")]//serilize 
        public bool DrugTaken { get; set; }

        [JsonProperty("drugTakenTime")]//serilize 
        public DateTime DrugTakenTime { get; set; }

        [JsonProperty("partitionKey")]//serilize 
        public string PartitionKey { get; set; }

        [JsonProperty("docType")]//serilize 
        public string DocType { get; set; }

        [JsonProperty("id")]//serilize 
        public string DocId { get; set; }
    }
}
