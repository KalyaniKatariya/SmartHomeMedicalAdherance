﻿/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/*Repo model reads all the records from the database and then they are
filtred again at APP model and only information that is related to user is displayed*/

namespace SHMA_CRUD.RepoModel
{
    public class PatientInfo
    {

        [JsonProperty("id")]//serilize 
        public string DocId { get; set; }

        [JsonProperty("patientId")]//serilize 
        public string PatientId { get; set; }

        [JsonProperty("firstName")]//serilize 
        public string FirstName { get; set; }

        [JsonProperty("lastName")]//serilize 
        public string LastName { get; set; }

        [JsonProperty("age")]//serilize 
        public string Age { get; set; }

        [JsonProperty("email")]//serilize 
        public string Email { get; set; }

        [JsonProperty("address")]//serilize 
        public string Address { get; set; }

        [JsonProperty("medicationId")]//serilize 
        public string MedicationId { get; set; }

        [JsonProperty("medicinName")]//serilize 
        public string MedicinName { get; set; }

        [JsonProperty("drugDose")]//serilize 
        public string DrugDose{ get; set; }

        [JsonProperty("drugInstruction")]//serilize 
        public string DrugInstruction { get; set; }

        [JsonProperty("caregiverId")]//serilize 
        public string CaregiverId{ get; set; }


        [JsonProperty("caregiverName")]//serilize 
        public string CaregiverName { get; set; }


        [JsonProperty("doctorId")]//serilize 
        public string DoctorId { get; set; }


        [JsonProperty("doctorName")]//serilize 
        public string DoctorName { get; set; }


        [JsonProperty("drugSchedules")]//serilize 
        public IList<Schedule> DrugSchedules { get; set; }
    }
}


