﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/*Repo model reads all the records from the database and then they are
filtred again at APP model and only information that is related to user is displayed*/
namespace SHMA_CRUD.RepoModel//No app model implemented for schedules. Data is directly send to web.
{
    public class Schedule
    {
        [JsonProperty("drugId")]//serilize 
        public string DrugId { get; set; }

        [JsonProperty("drugDose")]//serilize 
        public string DrugDose { get; set; }

        [JsonProperty("scheduleTime")]//serilize 
        public IList<string> ScheduleTime { get; set; }
    }
}
