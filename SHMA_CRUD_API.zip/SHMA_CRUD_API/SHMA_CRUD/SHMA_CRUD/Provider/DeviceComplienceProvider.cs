﻿using SHMA_CRUD.ApiModel;
using SHMA_CRUD.RepoModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMA_CRUD.Provider
{
    public class DeviceComplienceProvider
    {
        private IdocdbRepository<PatientComplienceDoc> _repository;//dependency injection

        // Constructor
        public DeviceComplienceProvider(IdocdbRepository<PatientComplienceDoc> repository)
        {
            _repository = repository;
            _repository.Initialize();
        }

        // Get current status
        public async Task PostStatus(PatientComplienceApi patientId)
        {
            foreach (var complience in patientId.ComplienceList)
            {
                PatientComplienceDoc compDoc = new PatientComplienceDoc();
                compDoc.DocId = Guid.NewGuid().ToString();
                compDoc.DocType = "ComplienceDoc";
                compDoc.DrugTaken = complience.DrugTaken;
                compDoc.DrugTakenTime = complience.DrugTakenTime;
                compDoc.MedicationId = complience.MedicationId;
                compDoc.PatientId = complience.PatientId;
                compDoc.PartitionKey = compDoc.PatientId;
                await _repository.UpdateAsync(compDoc.DocId, compDoc);
            }
        }
    }
}
