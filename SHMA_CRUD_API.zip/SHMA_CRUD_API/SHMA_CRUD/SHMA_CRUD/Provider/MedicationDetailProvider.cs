﻿using SHMA_CRUD.ApiModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMA_CRUD.Provider
{
    public class MedicationDetailProvider
    {
        private IdocdbRepository<PatientManagmentService> _repository;//dependency injection

        // Constructor
        public MedicationDetailProvider(IdocdbRepository<PatientManagmentService> repository)
        {
            _repository = repository;
            _repository.Initialize();
        }

        // Get current status and check wheather user is compliant or not. Post status on website
        public async Task<MedicationStatusModel> GetCurrentStatus(string patientId)
        {
            var status = true;
            var details = "";
            var complienceDocs = await _repository.GetTwoDayPatientComplienceDoc(patientId);

            foreach (var complienceDoc in complienceDocs)
            {
                if (complienceDoc.DrugTaken == false)
                {
                    status = false;
                    details = $"Medicine: {complienceDoc.MedicationId}, not taken  at: {complienceDoc.ScheduleTime}";
                    break;
                }
            }

            MedicationStatusModel returnValue = new MedicationStatusModel()
            {
                Status = status,
                Details = details
            };

            return returnValue;
        }
    }
}
