﻿/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//Interface for patient schedule details

namespace SHMA_CRUD.Provider
{
    interface IPSheduleDetailProvider
    {
        string GetPatientSchedule(string id);
    }
}
