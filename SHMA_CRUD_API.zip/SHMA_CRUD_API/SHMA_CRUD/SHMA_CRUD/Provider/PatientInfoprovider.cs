﻿/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SHMA_CRUD.ApiModel;

namespace SHMA_CRUD.Provider
{
    public class PatientInfoprovider
    {
        private IdocdbRepository<PatientManagmentService> _repository;//dependency injection

        // Constructor
        public PatientInfoprovider(IdocdbRepository<PatientManagmentService> repository)
        {
            _repository = repository;
            _repository.Initialize();
        }

        //Save-post/put Document
        public async Task<PatientInfoModel> Getpatientdetail(string id)
        {
            var patientDetails = await _repository.GetAsync(id);
            PatientInfoModel returnpatientdet = new PatientInfoModel();
            foreach (var patientDt in patientDetails)
            {
                if (patientDt != null)
                {
                    returnpatientdet.FirstName = patientDt.FirstName; //database value assigned to variable which is declared in app model

                    returnpatientdet.LastName = patientDt.LastName;

                    returnpatientdet.Age = patientDt.Age;

                    returnpatientdet.Email = patientDt.Email;

                    returnpatientdet.Address = patientDt.Address;

                    returnpatientdet.MedicinName = patientDt.MedicinName;

                    returnpatientdet.DrugDose = patientDt.DrugDose;

                    returnpatientdet.DrugInstruction = patientDt.DrugInstruction;

                    returnpatientdet.CaregiverName = patientDt.CaregiverName;

                    returnpatientdet.DoctorName = patientDt.DoctorName;

                    break;
                }
            }


            return returnpatientdet;



        }
    }
}
