﻿/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/

using SHMA_CRUD.ApiModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMA_CRUD.Provider
{
    public interface IMedicationDetailProvider
    {
        Task<MedicationStatusModel> GetCurrentStatus(string patientId);
    }
}
