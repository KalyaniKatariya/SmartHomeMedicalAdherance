﻿using SHMA_CRUD.ApiModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//Interface implemented for Device complience
namespace SHMA_CRUD.Provider
{
    public interface IDeviceComplienceProvider
    {
        Task PostStatus(PatientComplienceApi patientId);
    }
}
