﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SHMA_CRUD.ApiModel;
using SHMA_CRUD.RepoModel;

namespace SHMA_CRUD.Provider
{
    public class PSheduleDetailProvider
    {
        private IdocdbRepository<PatientManagmentService> _repository;//dependency injection

        // Constructor
        public PSheduleDetailProvider(IdocdbRepository<PatientManagmentService> repository)
        {
            _repository = repository;
            _repository.Initialize();
        }

        //call getpatientSchedule
        public async Task<List<Schedule>> GetPatientSchedule(string id)
        {
            var returnpatients = await _repository.GetAsync(id);//do we need to write another method?istead of getasnc
            List<Schedule> returnpatientsch = new List<Schedule>();
            foreach (var returnpatient in returnpatients)
            {
                foreach (var sched in returnpatient.DrugSchedules)
                {
                    returnpatientsch.Add(sched);
                }
                break;
            }
            //Schedule returnpatientsch = new PSheduleDetailModel();
            return returnpatientsch;
        }
    }
}
