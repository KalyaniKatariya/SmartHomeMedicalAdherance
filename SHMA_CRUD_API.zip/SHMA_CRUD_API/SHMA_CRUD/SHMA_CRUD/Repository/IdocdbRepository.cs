﻿
/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/

using Microsoft.Azure.Documents;//added new packge for document
using SHMA_CRUD.RepoModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Creating repository to querry database by creating public interface

namespace SHMA_CRUD
{
    public interface IdocdbRepository<T> where T :class //should be able to do crud applictions for anyone
    {
        Task<IList<PatientInfo>> GetAsync(string id);
        Task<Document> CreateAsync(T value);
        Task<Document> UpdateAsync(string id, T value);//id and current object
        Task DeleteAsync(string id);

        void Initialize();

       Task<IList<PatientComplienceDoc>> GetTwoDayPatientComplienceDoc(string patientId);

        //Task GetAsync(object patientId);
    }
}
