﻿/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using SHMA_CRUD.RepoModel;

//In futer database and colection creation related class can be separate out from the functions. Cureent code writting is not the best practice
namespace SHMA_CRUD
{
    public class DocdbRepository<T> : IdocdbRepository<T> where T : class
    {
        private static readonly string DatabaseID = "SHMA_CRUD";//generally write in config file- SHMA_CRUD id db name
        private static readonly string CollectionID = "Patient_Info";
        private static readonly string AzureEndPoint= "https://shmadb.documents.azure.com:443/"; //URI from Key section in Azure cosmos DB setup
        private static readonly string AzureAuthKey = "nVWqnNoVqPbM7R297RBlUGP4rTxU890K0rw1LIBJSwBKd8z8Q23CInbq5q6E2JaJOoLVk5L0RtzW0ycpAISkaQ=="; //Azure primary key from key section COSMOS DB- primary key values
        private static DocumentClient client; //DocumentDB package 

        //Client Initialization
        public void Initialize()
        {
            client = new DocumentClient(new Uri(AzureEndPoint), AzureAuthKey, 
                new ConnectionPolicy { EnableEndpointDiscovery = false });//client initialization
            CreateDbIfNotExist().Wait();//create database if it does not exist
                CreateCollectionIfNotExist().Wait(); //create collection if it does not exist.creat async wait version
        }

        //Create collection
        private async Task CreateCollectionIfNotExist()
        {
            try
            {
                await client.ReadDocumentCollectionAsync(
                    UriFactory.CreateDocumentCollectionUri(DatabaseID, CollectionID));
     
            }
            catch (DocumentClientException ex)
            {
                if (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDocumentCollectionAsync(
                        UriFactory.CreateDatabaseUri(DatabaseID),
                        new DocumentCollection { Id = CollectionID },
                        new RequestOptions { OfferThroughput = 1000 });
                }
                else
                {
                    throw ex;
                }
            }
        }

        //Create database
        private async Task CreateDbIfNotExist()
        {
            try
            {
                await client.ReadDatabaseAsync(UriFactory.CreateDatabaseUri(DatabaseID));
            } catch (DocumentClientException ex)
            {
                if (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDatabaseAsync(new Database { Id = DatabaseID });
                }
            }
        }

        //Create record/document
        public async Task<Document> CreateAsync(T value)
        {
            return await client.CreateDocumentAsync(
                UriFactory.CreateDocumentCollectionUri(DatabaseID, CollectionID), value);
        }

        //Delete Document
        public async Task DeleteAsync(string id)
        {
            await client.DeleteDocumentAsync(UriFactory.CreateDocumentUri(DatabaseID, CollectionID, id));
        }
        

        //Read patient information from database document
        public async Task<IList<PatientInfo>> GetAsync(string pid)
        {
            List<PatientInfo> ret1 = new List<PatientInfo>();

            var queryS = "SELECT * FROM c WHERE c.patientId = @patientId";
            var pars = new SqlParameterCollection();

            pars.Add(new SqlParameter("@patientId", pid));

            SqlQuerySpec query = new SqlQuerySpec(queryS, pars);
            FeedOptions option = new FeedOptions() { MaxItemCount = 1000 };
            try
            {
                var querySalesOrder = client.CreateDocumentQuery<PatientInfo>
            (UriFactory.CreateCollectionUri(DatabaseID, CollectionID), query, option).AsDocumentQuery();

                var results = await querySalesOrder.ExecuteNextAsync<PatientInfo>();
                foreach (var result in results)
                {
                    ret1.Add(result);
                }
                return ret1;

            }
            catch (Exception e)
            {

            }
            return null;
           
        }

       //Update Document - working code but not used for project
        public async Task<Document> UpdateAsync(string id, T value)
        {
            try
            {
                var uri = UriFactory.CreateCollectionUri(DatabaseID, CollectionID);///Could be in try catch good practice.
                Document document = await client.CreateDocumentAsync(uri, value);
                return document;
            }
            catch (Exception e)
            {

            }
            return null;
        }

        //Get the patients record to verify medication status.
        public async Task<IList<PatientComplienceDoc>> GetTwoDayPatientComplienceDoc(string patientId)
        {
            List<PatientComplienceDoc> ret = new List<PatientComplienceDoc>();

            var queryS = "SELECT * FROM c WHERE c.patientId = @patientId";
            var pars = new SqlParameterCollection();

            pars.Add(new SqlParameter("@patientId", patientId));
            
            SqlQuerySpec query = new SqlQuerySpec(queryS, pars);
            FeedOptions option = new FeedOptions() { MaxItemCount = 1000 };
            try
            {
                var querySalesOrder = client.CreateDocumentQuery<PatientComplienceDoc>(UriFactory.CreateCollectionUri(DatabaseID, CollectionID), query, option).AsDocumentQuery();

                var results = await querySalesOrder.ExecuteNextAsync<PatientComplienceDoc>();

                foreach (var result in results)
                {
                    ret.Add(result);
                }
                return ret;
            }
            catch (Exception e)
            {

            }
            return null;
        }
    }
}

