﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SHMA_CRUD.ApiModel;
using SHMA_CRUD.Provider;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents;
using SHMA_CRUD.RepoModel;

namespace SHMA_CRUD.Controllers
{

    [Produces("application/json")]
    [Route("api/PSchedules")]

    public class PSchedulesController : Controller
    {
        private PSheduleDetailProvider _patientScheduleProvider;//dependency injection
        public PSchedulesController(IdocdbRepository<PatientManagmentService> repository)
        {
            _patientScheduleProvider = new PSheduleDetailProvider(repository);
        }
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public async Task<List<Schedule>> Get(string id)
        {
            var PSheduleDetailModel = await _patientScheduleProvider.GetPatientSchedule(id);
            return PSheduleDetailModel;
        }
    }
}
