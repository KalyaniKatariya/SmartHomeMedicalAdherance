﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHMA_CRUD.ApiModel;
using SHMA_CRUD.Provider;
using SHMA_CRUD.RepoModel;

namespace SHMA_CRUD.Controllers
{
    [Produces("application/json")]
    [Route("api/DeviceComplience")]
    public class DeviceComplienceController : Controller
    {
        private DeviceComplienceProvider _medicationProvider;//dependency injection
        public DeviceComplienceController(IdocdbRepository<PatientComplienceDoc> repository)
        {
            _medicationProvider = new DeviceComplienceProvider(repository);
        }

        // POST: api/DeviceComplience
        [HttpPost]
        public async Task Post([FromBody]PatientComplienceApi value)
        {
            await _medicationProvider.PostStatus(value);
        }
        
    }
}
