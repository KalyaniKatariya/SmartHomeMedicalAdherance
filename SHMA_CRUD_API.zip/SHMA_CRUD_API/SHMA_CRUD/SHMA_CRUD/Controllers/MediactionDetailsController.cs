﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHMA_CRUD.ApiModel;
using SHMA_CRUD.Provider;

namespace SHMA_CRUD.Controllers
{
    [Produces("application/json")]
    [Route("api/MediactionDetails")]
    public class MediactionDetailsController : Controller
    {
        private MedicationDetailProvider _medicationProvider;//dependency injection
        public MediactionDetailsController(IdocdbRepository<PatientManagmentService> repository)
        {
            _medicationProvider = new MedicationDetailProvider(repository);
        }

        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
        // GET api/<controller>/id
        [HttpGet("{id}")]
        public async Task<MedicationStatusModel> Get(string id)
        {
            var medicationStatusModel = await _medicationProvider.GetCurrentStatus(id);
            return medicationStatusModel;
        }
    }
}