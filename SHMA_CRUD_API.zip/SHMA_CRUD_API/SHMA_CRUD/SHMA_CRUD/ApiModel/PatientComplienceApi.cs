﻿/*=====================================
@Author name: Kalyani Katariya
@Version: 1.0 Date : 08/03/2018
======================================*/

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMA_CRUD.ApiModel
{
    public class PatientComplienceApi
    {
        [JsonProperty("complienceList")]//serilize 
        public List<Complience> ComplienceList { get; set; }
    }
}
