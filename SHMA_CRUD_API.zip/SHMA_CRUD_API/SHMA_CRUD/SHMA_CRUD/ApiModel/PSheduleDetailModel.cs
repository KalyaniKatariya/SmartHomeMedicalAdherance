﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SHMA_CRUD.ApiModel
{
    public class PSheduleDetailModel
    {
       

        [JsonProperty("scheduleTime")]//serilize 
        public DateTime ScheduleTime { get; set; }

        [JsonProperty("drugtaken")]//serilize 
        public bool DrugTaken { get; set; }

        [JsonProperty("drugTakenTime")]//serilize 
        public DateTime DrugTakenTime { get; set; }

            
    }
}
