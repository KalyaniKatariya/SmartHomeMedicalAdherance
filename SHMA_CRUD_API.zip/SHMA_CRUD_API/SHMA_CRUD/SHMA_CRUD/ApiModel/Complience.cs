﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMA_CRUD.ApiModel
{
    public class Complience
    {
        [JsonProperty("patientId")]//serilize 
        public string PatientId { get; set; }

        [JsonProperty("medicationId")]//serilize 
        public string MedicationId { get; set; }

        [JsonProperty("scheduleTime")]//serilize 
        public DateTime ScheduleTime { get; set; }

        [JsonProperty("drugtaken")]//serilize 
        public bool DrugTaken { get; set; }

        [JsonProperty("drugTakenTime")]//serilize 
        public DateTime DrugTakenTime { get; set; }
    }
}
