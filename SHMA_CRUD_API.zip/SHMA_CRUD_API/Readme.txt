This is created by Kalyani Katariya
This contains the web api code which runs on Windows 10 
This code is created in asp .net using the asp.net framework.The code is devided on Controller,Provider,Interface,Repo model,App model. 
App model publish the data on website required for user. 
