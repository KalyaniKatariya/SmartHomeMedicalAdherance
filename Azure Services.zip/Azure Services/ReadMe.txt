This file is created by Abdullah
This folder contains pictures of Azure services used in the project:
1) IoT Hub- shows a picture of the IoT hub implemented
2) IoT - shows a picture of code running on Rasberry Pi
3) Service Bus - shows a picture of service bus being used
4) Function - shows a picture of function being used
5) Api - shows a picture of api deployed to Azure
6) Website - shows a  picture of website deployed to Azure
7) DocDB - shows a picture of docDB (NoSQL database) deployed to Azure